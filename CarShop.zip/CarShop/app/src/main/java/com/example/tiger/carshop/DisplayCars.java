package com.example.tiger.carshop;

import android.support.annotation.Nullable;
import android.view.View;
import android.view.LayoutInflater;
import android.view.ViewGroup;
import android.os.Bundle;
import android.support.v4.app.Fragment;

/**
 * Created by Tiger on 11/8/2017.
 */

public class DisplayCars extends Fragment{

    public DisplayCars(){}

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState){
        View showCars = inflater.inflate(R.layout.show_cars_layout, container, false);

        return showCars;
    }

    @Override
    protected Object clone() throws CloneNotSupportedException{
        return super.clone();
    }
}
