package com.example.tiger.carshop;

import android.database.Cursor;
import android.support.annotation.Nullable;
import android.view.View;
import android.view.LayoutInflater;
import android.view.ViewGroup;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.ArrayList;

/**
 * Created by Tiger on 11/8/2017.
 */

public class DisplayCars extends Fragment{

    View showCars;
    CarDatabase cdBase;
    String carBrand, minimum, maximum;
    ListView listOfCars;

    public DisplayCars(){}

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState){
        showCars = inflater.inflate(R.layout.show_cars_layout, container, false);
      //  cdBase = new CarDatabase(showCars.getContext());

        return showCars;
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState){
        super.onViewCreated(view, savedInstanceState);

        listOfCars = (ListView)view.findViewById(R.id.listOfCars);
    }

    protected void updateList(ArrayList<String> searchResults){
        ArrayAdapter<String> adapt = new ArrayAdapter<String>(showCars.getContext(), R.layout.item_in_list, searchResults);
        listOfCars.setAdapter(adapt);
    }

    @Override
    protected Object clone() throws CloneNotSupportedException{
        return super.clone();
    }
}
