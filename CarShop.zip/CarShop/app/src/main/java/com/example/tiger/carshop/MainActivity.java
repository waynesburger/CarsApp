package com.example.tiger.carshop;

import android.os.Bundle;
import android.support.design.widget.TabLayout;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v4.app.FragmentManager;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.support.v7.app.AlertDialog;
import android.support.v4.view.ViewPager;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.app.FragmentTransaction;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.ArrayAdapter;
import android.content.DialogInterface;
import android.database.Cursor;

import java.util.List;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements BuyCar.Sendable{

    TabLayout tabs;
    ViewPager pages;
    CarDatabase cdBase;
    MyVPAdapter myvpadapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        tabs = (TabLayout)findViewById(R.id.tabs);
        pages = (ViewPager)findViewById(R.id.thePage);
        tabs.setupWithViewPager(pages);
        setUpViewPager(pages);

        FragmentManager fm = getSupportFragmentManager();
        FragmentTransaction ft = fm.beginTransaction();
        DisplayCars displaycars = new DisplayCars();
        ft.add(R.id.thePage, displaycars, "showcarstag");
        ft.commit();

        cdBase = new CarDatabase(this);
    }

    public void setUpViewPager(ViewPager pages){
        MyVPAdapter adapter = new MyVPAdapter(getSupportFragmentManager());
        adapter.AddAPage(new BuyCar(), "Buy");
        adapter.AddAPage(new SellCar(), "Sell");
        adapter.AddAPage(new DisplayCars(), "Show Options");

        pages.setAdapter(adapter);
    }

    @Override
    public void sendInfo(ArrayList<String> searchResults){
       //String tag = "android:switcher:" + R.id.thePage + ":" + "2";
        /*DisplayCars displaycars = (DisplayCars)getSupportFragmentManager()
                                   .findFragmentByTag(tag);*/

        DisplayCars displaycars = (DisplayCars)getSupportFragmentManager()
                                    .findFragmentByTag("showcarstag");

        if(displaycars != null) {
            displaycars.updateList(searchResults);
        }
        tabs.setupWithViewPager(pages);
        pages.setCurrentItem(2);
    }

    public class MyVPAdapter extends FragmentPagerAdapter{
        private List<Fragment> fragments = new ArrayList<>();
        private List<String> titles = new ArrayList<>();

        public MyVPAdapter(FragmentManager fm) {
            super(fm);
        }

        public void AddAPage(Fragment f, String t){
            fragments.add(f);
            titles.add(t);
        }

        @Override
        public Fragment getItem(int position){ return fragments.get(position); }

        @Override
        public long getItemId(int position) {
            return super.getItemId(position);
        }

        @Override
        public int getItemPosition(Object object) {
            return super.getItemPosition(object);
        }

        @Override
        public CharSequence getPageTitle(int position) {
            return titles.get(position);
        }

        @Override
        public int getCount() {
            return fragments.size();
        }

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
