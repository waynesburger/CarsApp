package com.example.tiger.carshop;

import android.os.Bundle;
import android.support.design.widget.TabLayout;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v4.app.FragmentManager;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.support.v7.app.AlertDialog;
import android.support.v4.view.ViewPager;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentPagerAdapter;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.ArrayAdapter;
import android.content.DialogInterface;
import android.database.Cursor;

import java.util.List;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements BuyCar.Sendable{

    TabLayout tabs;
    ViewPager pages;
    CarDatabase cdBase;
    MyVPAdapter myvpadapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        tabs = (TabLayout)findViewById(R.id.tabs);
        pages = (ViewPager)findViewById(R.id.thePage);
        tabs.setupWithViewPager(pages);
        setUpViewPager(pages);

        cdBase = new CarDatabase(this);

    }

    public void setUpViewPager(ViewPager pages){
        MyVPAdapter adapter = new MyVPAdapter(getSupportFragmentManager());
        adapter.AddAPage(new BuyCar(), "Buy");
        adapter.AddAPage(new SellCar(), "Sell");
        adapter.AddAPage(new DisplayCars(), "Show Options");

        pages.setAdapter(adapter);
    }

    @Override
    public void sendInfo(ArrayList<String> searchResults){
       String tag = "android:switcher:" + R.id.thePage + ":" + "2";
        DisplayCars displaycars = (DisplayCars)getSupportFragmentManager()
                                   .findFragmentByTag(tag);
        //DisplayCars displaycars = (DisplayCars)getSupportFragmentManager().findFragmentById(R.id.showcarsview);
        if(displaycars != null) {
            displaycars.updateList(searchResults);
        }
    }

    public class MyVPAdapter extends FragmentPagerAdapter{
        private List<Fragment> fragments = new ArrayList<>();
        private List<String> titles = new ArrayList<>();

        public MyVPAdapter(FragmentManager fm) {
            super(fm);
        }

        public void AddAPage(Fragment f, String t){
            fragments.add(f);
            titles.add(t);
        }

        @Override
        public Fragment getItem(int position){ return fragments.get(position); }

        @Override
        public long getItemId(int position) {
            return super.getItemId(position);
        }

        @Override
        public int getItemPosition(Object object) {
            return super.getItemPosition(object);
        }

        @Override
        public CharSequence getPageTitle(int position) {
            return titles.get(position);
        }

        @Override
        public int getCount() {
            return fragments.size();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    /*/search car method
    public void searchCar(){
        setContentView(R.layout.buy_car_layout);
        buyBrand = (EditText)findViewById(R.id.enterBrand);
        minPrice = (EditText)findViewById(R.id.enterPrice1);
        maxPrice = (EditText)findViewById(R.id.enterPrice2);
        searchButton = (Button)findViewById(R.id.seeOptions);
        searchButton.setOnClickListener(
                new View.OnClickListener(){
                    @Override
                    public void onClick(View view){
                        String carBrand = buyBrand.getText().toString();
                        String min = minPrice.getText().toString();
                        String max = maxPrice.getText().toString();
                        Cursor carCursor = cdBase.getSpecified(carBrand, min, max);

                        ListView listOfCars = (ListView)findViewById(R.id.listOfCars);
                        ArrayList<String> searchResults = new ArrayList<String>();
                        String nextResult;
                        while(carCursor.moveToNext()){
                            nextResult = "BRAND: " + "Brand: " + carCursor.getString(1) + "\n" +
                                    "YEAR: " + carCursor.getString(2) + "\n" +
                                    "PRICE: $" + carCursor.getString(3);

                            searchResults.add(nextResult);
                        }

                        ArrayAdapter<String> adapt = new ArrayAdapter<String>(MainActivity.this, R.layout.item_in_list, searchResults);

                        listOfCars.setAdapter(adapt);
                    }
                }
        );
    }*/

    /*/addCar method
    public void addCar(){
        sellBrand = (EditText)findViewById(R.id.submitBrand);
        sellYear = (EditText)findViewById(R.id.enterYear);
        sellPrice = (EditText)findViewById(R.id.enterPrice);
        addButton = (Button)findViewById(R.id.submitCar);
        addButton.setOnClickListener(
                new View.OnClickListener(){
                    @Override
                    public void onClick(View view){
                        String newCarBrand = sellBrand.getText().toString();
                        String newCarYear = sellYear.getText().toString();
                        String newCarPrice = sellPrice.getText().toString();

                        //do this only if YES is clicked on the dialog box
                        boolean successCheck = cdBase.addNewCar(newCarBrand, newCarYear, newCarPrice);
                        if(successCheck){ displayMessage("New car added :)"); }
                        else{ displayMessage("Car not added :/"); }

                    }
                }
        );
    }*/

    /*public void displayMessage(String message){
        AlertDialog.Builder build = new AlertDialog.Builder(this);
        build.setCancelable(true);
        build.setMessage(message);
        build.show();
    }*/




}
