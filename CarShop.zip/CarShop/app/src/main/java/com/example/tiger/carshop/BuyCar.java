package com.example.tiger.carshop;

import android.database.Cursor;
import android.support.annotation.Nullable;
import android.view.View;
import android.view.LayoutInflater;
import android.view.ViewGroup;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Button;
import android.widget.ListView;
import android.content.Context;

import java.util.ArrayList;

/**
 * Created by Tiger on 11/8/2017.
 */

public class BuyCar extends Fragment implements View.OnClickListener{

    Sendable sender;
    CarDatabase cdBase;
    EditText buyBrand, minPrice, maxPrice;
    Button searchButton;

    public BuyCar(){}

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState){
        final View buyPage = inflater.inflate(R.layout.buy_car_layout, container, false);

        cdBase = new CarDatabase(buyPage.getContext());

        return buyPage;
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState){
        super.onViewCreated(view, savedInstanceState);

        buyBrand = (EditText)view.findViewById(R.id.enterBrand);
        minPrice = (EditText)view.findViewById(R.id.enterPrice1);
        maxPrice = (EditText)view.findViewById(R.id.enterPrice2);
        searchButton = (Button)view.findViewById(R.id.seeOptions);

        searchButton.setOnClickListener(
                new View.OnClickListener(){
                    @Override
                    public void onClick(View view){
                        ArrayList<String> searchResults = new ArrayList<String>();
                        String carBrand = buyBrand.getText().toString();
                        String min = minPrice.getText().toString();
                        String max = maxPrice.getText().toString();

                        Cursor carCursor = cdBase.getSpecified(carBrand, min, max);
                        String nextResult;
                        while(carCursor.moveToNext()){
                            nextResult = "BRAND: " + "Brand: " + carCursor.getString(1) + "\n" +
                                    "YEAR: " + carCursor.getString(2) + "\n" +
                                    "PRICE: $" + carCursor.getString(3);

                            searchResults.add(nextResult);
                        }

                        sender.sendInfo(searchResults);
                    }
                }
        );
    }

    interface Sendable{
        void sendInfo(ArrayList<String> searchResults);
    }

    /*@Override
    protected void sendInfo(ArrayList<String> searchresults){

    }*/

    @Override
    public void onAttach(Context context){
        super.onAttach(context);

        try{
            sender = (Sendable)getActivity();
        }catch(ClassCastException ex){
            throw new ClassCastException("something went wrong, try again");
        }
    }

    @Override
    protected Object clone() throws CloneNotSupportedException {
        return super.clone();
    }


    @Override
    public void onClick(View v) {

    }
}
