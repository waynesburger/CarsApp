package com.example.tiger.carshop;

import android.database.Cursor;
import android.support.annotation.Nullable;
import android.view.View;
import android.view.LayoutInflater;
import android.view.ViewGroup;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Button;
import android.widget.ListView;

import java.util.ArrayList;

/**
 * Created by Tiger on 11/8/2017.
 */

public class BuyCar extends Fragment{

    EditText buyBrand, minPrice, maxPrice;
    Button searchButton;

    public BuyCar(){}

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState){
        View buyPage = inflater.inflate(R.layout.buy_car_layout, container, false);

        return buyPage;
    }

    @Override
    protected Object clone() throws CloneNotSupportedException {
        return super.clone();
    }


}
