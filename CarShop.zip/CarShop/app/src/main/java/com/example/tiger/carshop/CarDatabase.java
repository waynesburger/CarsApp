package com.example.tiger.carshop;

import android.database.sqlite.SQLiteOpenHelper;
import android.database.sqlite.SQLiteDatabase;
import android.content.Context;
import android.content.ContentValues;
import android.database.Cursor;

/**
 * Created by Tiger on 11/9/2017.
 */

public class CarDatabase extends SQLiteOpenHelper {

    public static final String DATABASE_NAME = "cars.db";
    public static final int DATABASE_VERSION = 4;
    String CREATE_QUERY = "CREATE TABLE " + CarItem.Info.TABLE_NAME + "("
            + CarItem.Info.COLUMN1 + " INTEGER PRIMARY KEY, "
            + CarItem.Info.COLUMN2 + " TEXT, "
            + CarItem.Info.COLUMN3 + " TEXT, "
            + CarItem.Info.COLUMN4 + " REAL);";

    public CarDatabase(Context con){
        super(con, DATABASE_NAME, null, DATABASE_VERSION);
        //Log.e("DATABASE OPERATIONS", "database created/opened");
    }

    @Override
    public void onCreate(SQLiteDatabase dbase){
        dbase.execSQL(CREATE_QUERY);
        //Log.e("DATABASE OPERATIONS", "table created");
    }

    @Override
    public void onUpgrade(SQLiteDatabase dbase, int older, int newer){
        dbase.execSQL("DROP TABLE IF EXISTS " + CarItem.Info.TABLE_NAME);
        onCreate(dbase);
    }

    public boolean addNewCar(String newCarBrand, String newCarYear, String newCarPrice){
        SQLiteDatabase thisdatabase = this.getWritableDatabase();
        ContentValues addValues = new ContentValues();
        addValues.put(CarItem.Info.COLUMN2, newCarBrand);
        addValues.put(CarItem.Info.COLUMN3, newCarYear);
        addValues.put(CarItem.Info.COLUMN4, newCarPrice);

        long success = thisdatabase.insert(CarItem.Info.TABLE_NAME, null, addValues);

        if(success == -1){ return false;}
        else{return true;}
    }

    public Cursor getSpecified(String carBrand, String min, String max){
        SQLiteDatabase dbase = this.getWritableDatabase();
        String qu = "SELECT * FROM " + CarItem.Info.TABLE_NAME +
                    " WHERE " + CarItem.Info.COLUMN2 + " == '" + carBrand +
                    "' AND " + CarItem.Info.COLUMN4 + " >= " + min +
                    " AND " + CarItem.Info.COLUMN4 + " <= " + max;
        Cursor carCursor = dbase.rawQuery(qu, null);
        return carCursor;
    }


}
