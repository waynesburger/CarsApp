package com.example.tiger.carshop;

import android.support.annotation.Nullable;
import android.view.View;
import android.view.LayoutInflater;
import android.view.ViewGroup;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.widget.EditText;
import android.widget.Button;

/**
 * Created by Tiger on 11/8/2017.
 */

public class SellCar extends Fragment{

    public SellCar(){}

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState){
        View sellPage = inflater.inflate(R.layout.sell_car_layout, container, false);

        return sellPage;
    }

    @Override
    protected Object clone() throws CloneNotSupportedException{
        return super.clone();
    }
}
