package com.example.tiger.carshop;

import android.support.annotation.Nullable;
import android.support.v7.app.AlertDialog;
import android.view.View;
import android.view.LayoutInflater;
import android.view.ViewGroup;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.widget.EditText;
import android.widget.Button;

/**
 * Created by Tiger on 11/8/2017.
 */

public class SellCar extends Fragment{

    CarDatabase cdBase;
    EditText sellBrand, sellYear, sellPrice;
    Button addButton;

    public SellCar(){}

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState){
        final View sellPage = inflater.inflate(R.layout.sell_car_layout, container, false);

        cdBase = new CarDatabase(sellPage.getContext());

        sellBrand = (EditText)sellPage.findViewById(R.id.submitBrand);
        sellYear = (EditText)sellPage.findViewById(R.id.enterYear);
        sellPrice = (EditText)sellPage.findViewById(R.id.enterPrice);
        addButton = (Button)sellPage.findViewById(R.id.submitCar);
        addButton.setOnClickListener(
                new View.OnClickListener(){
                    @Override
                    public void onClick(View view){
                        String newCarBrand = sellBrand.getText().toString();
                        String newCarYear = sellYear.getText().toString();
                        String newCarPrice = sellPrice.getText().toString();

                        //do this only if YES is clicked on the dialog box
                        boolean successCheck = cdBase.addNewCar(newCarBrand, newCarYear, newCarPrice);
                        if(successCheck){ displayMessage(sellPage, "New car added :)"); }
                        else{ displayMessage(sellPage, "Car not added :/"); }

                    }
                }
        );

        return sellPage;
    }

    public void displayMessage(View view, String message){
        AlertDialog.Builder build = new AlertDialog.Builder(view.getContext());
        build.setCancelable(true);
        build.setMessage(message);
        build.show();
    }

    @Override
    protected Object clone() throws CloneNotSupportedException{
        return super.clone();
    }
}
