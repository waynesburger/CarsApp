package com.example.tiger.carshop;

/**
 * Created by Tiger on 11/9/2017.
 */

public class CarItem {
    public static abstract class Info{
        public static final String TABLE_NAME = "car_table";
        public static final String COLUMN1 = "ID";
        public static final String COLUMN2 = "BRAND";
        public static final String COLUMN3 = "YEAR";
        public static final String COLUMN4 = "PRICE";
    }
}
